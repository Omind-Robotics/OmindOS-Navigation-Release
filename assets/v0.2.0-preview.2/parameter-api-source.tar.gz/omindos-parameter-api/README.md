# OmindOS parameter API source · 0.2.0-preview.2

This source archive contains the parameter API, configuration tests, examples and documentation. It does not contain the Docker navigation runtime. Download the full Linux amd64 package from the Release page for navigation installation.

Run from this extracted directory with Python 3.10 or later:

```bash
python3 -m unittest discover -s tests -v
python3 scripts/robot_parameter_api.py --store /absolute/path/robot-configurations --port 8085
```

Use examples/robot-parameters.synthetic.json for the initial HTTP demonstration. It contains synthetic parameters, not hardware calibration. See docs/ROBOT_PARAMETER_API.zh-CN.md for POST/GET usage. Runtime activation, the 3D UI and physical robot control are not included.
